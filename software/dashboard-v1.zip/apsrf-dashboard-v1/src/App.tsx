import { DependencyGraph, BP1Status, GovernanceStatus, HealthSummary, RiskMonitor } from './components/Graphs';
import { Panel } from './components/Panel';
import { ProtocolGrid } from './components/ProtocolCard';
import { AuditHistory, ClassificationMatrix, ConflictMonitor, DependencyList, MetricsRail, RegistryTable } from './components/Tables';
import { Shell } from './components/Shell';

function App() {
  return (
    <Shell>
      <div className="dashboard-grid">
        <Panel id="inventory" title="Protocol Inventory" kicker="Active ecosystem">
          <ProtocolGrid />
        </Panel>

        <Panel id="registry" title="Protocol Registry" kicker="Local source of truth">
          <RegistryTable />
        </Panel>

        <Panel id="classification" title="Protocol Classification Matrix" kicker="APSRF taxonomy">
          <ClassificationMatrix />
          <MetricsRail />
        </Panel>

        <Panel id="dependencies" title="Dependency Graph" kicker="Bridge-mediated relationships">
          <DependencyGraph />
          <DependencyList />
        </Panel>

        <Panel id="conflict-monitor" title="Conflict Monitor" kicker="Protocol interaction watchlist">
          <ConflictMonitor />
        </Panel>

        <Panel id="risk-monitor" title="Risk Monitor" kicker="Governance and chaining risks">
          <RiskMonitor />
        </Panel>

        <Panel id="governance" title="Governance Status" kicker="Research integrity">
          <GovernanceStatus />
        </Panel>

        <Panel id="bp1" title="BP1 Mediation Status" kicker="Bridge lifecycle">
          <BP1Status />
        </Panel>

        <Panel id="health" title="Ecosystem Health Summary" kicker="Observable indicators">
          <HealthSummary />
        </Panel>

        <Panel id="audit" title="Audit History" kicker="Experiment trail">
          <AuditHistory />
        </Panel>
      </div>
    </Shell>
  );
}

export default App;
