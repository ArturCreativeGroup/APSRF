export type ProtocolClass = 'A-F' | 'B-S' | 'C-C' | 'D-R' | 'E-P' | 'F-B' | 'G-P' | 'H-M' | 'I-E';

export type ProtocolState = 'Active' | 'Candidate' | 'Draft' | 'Experimental' | 'Reference';

export type RiskLevel = 'Low' | 'Medium' | 'High';

export interface Protocol {
  id: string;
  name: string;
  shortName: string;
  version: string;
  state: ProtocolState;
  primaryClass: ProtocolClass;
  secondaryClass?: ProtocolClass;
  complexity: 1 | 2 | 3 | 4 | 5;
  purpose: string;
  observableEffects: string[];
  source: string;
  priorityBand: 'P0' | 'P1' | 'P2' | 'P3' | 'P4' | 'P5';
}

export interface Dependency {
  from: string;
  to: string;
  relation: string;
  criticality: RiskLevel;
}

export interface Conflict {
  id: string;
  title: string;
  protocols: string[];
  status: 'Watch' | 'Contained' | 'Active';
  severity: RiskLevel;
  description: string;
}

export interface AuditEvent {
  id: string;
  event: string;
  protocol: string;
  outcome: string;
  risk: RiskLevel;
}

export interface Metric {
  id: string;
  name: string;
  definition: string;
}
