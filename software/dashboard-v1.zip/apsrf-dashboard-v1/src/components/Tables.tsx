import { auditHistory, classRegistry, conflicts, dependencies, metrics, protocols } from '../data/apsrfData';

export function RegistryTable() {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Protocol</th><th>Class</th><th>State</th><th>Priority</th></tr></thead>
        <tbody>
          {protocols.map((p) => (
            <tr key={p.id}>
              <td><strong>{p.shortName}</strong><span>{p.name}</span></td>
              <td>{p.primaryClass}{p.secondaryClass ? ` / ${p.secondaryClass}` : ''}</td>
              <td>{p.state}</td>
              <td>{p.priorityBand}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function ClassificationMatrix() {
  return (
    <div className="matrix">
      {classRegistry.map((item) => (
        <div className="matrix-cell" key={item.code}>
          <strong>{item.code}</strong>
          <span>{item.name}</span>
          <p>{item.purpose}</p>
          <em>{item.risk} risk</em>
        </div>
      ))}
    </div>
  );
}

export function MetricsRail() {
  return (
    <div className="metrics-rail">
      {metrics.map((metric) => (
        <div key={metric.id}>
          <strong>{metric.id}</strong>
          <span>{metric.name}</span>
        </div>
      ))}
    </div>
  );
}

export function DependencyList() {
  return (
    <div className="dependency-list">
      {dependencies.map((d) => (
        <div className="dependency" key={`${d.from}-${d.to}`}>
          <span className={`dot ${d.criticality.toLowerCase()}`} />
          <strong>{d.from}</strong>
          <span>→</span>
          <strong>{d.to}</strong>
          <em>{d.relation}</em>
        </div>
      ))}
    </div>
  );
}

export function ConflictMonitor() {
  return (
    <div className="conflict-grid">
      {conflicts.map((conflict) => (
        <article key={conflict.id} className={`conflict ${conflict.severity.toLowerCase()}`}>
          <div><span>{conflict.status}</span><strong>{conflict.severity}</strong></div>
          <h4>{conflict.title}</h4>
          <p>{conflict.description}</p>
          <small>{conflict.protocols.join(' · ')}</small>
        </article>
      ))}
    </div>
  );
}

export function AuditHistory() {
  return (
    <div className="timeline">
      {auditHistory.map((event) => (
        <div className="timeline-item" key={event.id}>
          <span className={`dot ${event.risk.toLowerCase()}`} />
          <div>
            <strong>{event.event}</strong>
            <p>{event.protocol} · {event.outcome}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
