import type { PropsWithChildren, ReactNode } from 'react';

interface PanelProps extends PropsWithChildren {
  id?: string;
  title: string;
  kicker?: string;
  action?: ReactNode;
}

export function Panel({ id, title, kicker, action, children }: PanelProps) {
  return (
    <section className="panel" id={id}>
      <div className="panel-head">
        <div>
          {kicker && <span className="eyebrow">{kicker}</span>}
          <h3>{title}</h3>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}
