import { Activity, Cpu, Gauge, GitBranch, ShieldCheck, TerminalSquare } from 'lucide-react';
import type { PropsWithChildren } from 'react';

const nav = [
  'Inventory',
  'Registry',
  'Classification',
  'Dependencies',
  'Conflict Monitor',
  'Risk Monitor',
  'Governance',
  'BP1',
  'Health',
  'Audit',
];

export function Shell({ children }: PropsWithChildren) {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon"><TerminalSquare size={22} /></div>
          <div>
            <span className="eyebrow">APSRF</span>
            <h1>Dashboard v1</h1>
          </div>
        </div>

        <nav>
          {nav.map((item) => (
            <a key={item} href={`#${item.toLowerCase().replace(/ /g, '-')}`}>{item}</a>
          ))}
        </nav>

        <div className="system-card">
          <div className="system-row"><ShieldCheck size={16} /> Governance active</div>
          <div className="system-row"><Cpu size={16} /> Local data only</div>
          <div className="system-row"><GitBranch size={16} /> BP1 mediated</div>
          <div className="system-row"><Gauge size={16} /> Observable effects</div>
        </div>
      </aside>

      <main className="main">
        <header className="hero">
          <div>
            <span className="eyebrow">Protocol Operating Environment</span>
            <h2>APSRF Ecosystem Console</h2>
            <p>
              A local, interactive visualization of APSRF protocols, classes,
              dependencies, governance state, and BP1 mediation flow.
            </p>
          </div>
          <div className="hero-status">
            <Activity size={18} />
            <div>
              <strong>Operational</strong>
              <span>No backend · no internal access simulation</span>
            </div>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}
