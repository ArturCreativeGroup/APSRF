import { bp1Lifecycle, healthSignals, riskSignals } from '../data/apsrfData';

export function DependencyGraph() {
  return (
    <div className="graph-canvas" aria-label="APSRF dependency graph">
      <div className="node n-governance">Governance</div>
      <div className="node n-core">APSRF Core</div>
      <div className="node n-bp1">BP1</div>
      <div className="node n-taxonomy">Taxonomy</div>
      <div className="node n-metrics">Metrics</div>
      <div className="node n-methodology">Methodology</div>
      <div className="node n-active">CRL · HCEP · HRR</div>
      <svg className="edges" viewBox="0 0 900 360" preserveAspectRatio="none">
        <path d="M450 55 L450 105 L450 145" />
        <path d="M450 205 L230 250" />
        <path d="M450 205 L450 250" />
        <path d="M450 205 L670 250" />
        <path d="M230 290 L450 320" />
        <path d="M450 290 L450 320" />
        <path d="M670 290 L450 320" />
      </svg>
    </div>
  );
}

export function BP1Status() {
  return (
    <div className="bp1-flow">
      {bp1Lifecycle.map((stage, index) => (
        <div className="flow-step" key={stage}>
          <span>{String(index + 1).padStart(2, '0')}</span>
          <strong>{stage}</strong>
          <em>online</em>
        </div>
      ))}
    </div>
  );
}

export function RiskMonitor() {
  return (
    <div className="signal-grid">
      {riskSignals.map((risk) => (
        <div className="signal" key={risk.label}>
          <div><strong>{risk.label}</strong><span>{risk.level}</span></div>
          <div className="bar"><i style={{ width: `${risk.value}%` }} /></div>
        </div>
      ))}
    </div>
  );
}

export function HealthSummary() {
  return (
    <div className="health-grid">
      {healthSignals.map((signal) => (
        <div className="health" key={signal.label}>
          <div className="dial" style={{ ['--score' as string]: `${signal.value * 3.6}deg` }}>
            <span>{signal.value}</span>
          </div>
          <strong>{signal.label}</strong>
        </div>
      ))}
    </div>
  );
}

export function GovernanceStatus() {
  const rules = [
    'Observation precedes interpretation',
    'No internal architecture claims',
    'Raw evidence remains auditable',
    'Protocols remain versioned',
    'Metrics remain observable',
    'Responsible research posture',
  ];
  return (
    <div className="governance-grid">
      {rules.map((rule) => (
        <div key={rule}><span />{rule}</div>
      ))}
    </div>
  );
}
