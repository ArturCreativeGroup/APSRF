import { protocols } from '../data/apsrfData';

const classNames = {
  'A-F': 'Formatting',
  'B-S': 'Structural',
  'C-C': 'Compression',
  'D-R': 'Reasoning',
  'E-P': 'Priority',
  'F-B': 'Bridge',
  'G-P': 'Persistence',
  'H-M': 'Meta',
  'I-E': 'Evaluation',
};

export function ProtocolGrid() {
  return (
    <div className="protocol-grid">
      {protocols.map((protocol) => (
        <article className="protocol-card" key={protocol.id}>
          <div className="protocol-topline">
            <span className={`state state-${protocol.state.toLowerCase()}`}>{protocol.state}</span>
            <span>{protocol.priorityBand}</span>
          </div>
          <h4>{protocol.shortName}</h4>
          <p>{protocol.purpose}</p>
          <div className="chip-row">
            <span className="chip">{protocol.primaryClass} · {classNames[protocol.primaryClass]}</span>
            {protocol.secondaryClass && <span className="chip ghost">{protocol.secondaryClass}</span>}
            <span className="chip ghost">L{protocol.complexity}</span>
          </div>
          <small>{protocol.source}</small>
        </article>
      ))}
    </div>
  );
}
