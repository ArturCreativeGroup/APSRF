# APSRF Dashboard v1

A production-oriented Vite + React + TypeScript dashboard that visualizes the APSRF protocol ecosystem as a protocol operating environment.

## APSRF extraction summary

The application uses only entities present in the uploaded APSRF archive:

- APSRF Core
- BP1 Bridge Protocol
- Protocol Taxonomy
- Metrics Specification
- Research Governance and Bias Control
- APSRF Experimental Methodology
- Cognitive Rendering Layer
- Human Communication Efficiency Protocol
- Human Rhythm Rendering

## Architecture proposal

The app is organized as a local, component-based interface:

- `src/data/apsrfData.ts` is the local source of truth.
- `src/types/apsrf.ts` defines protocol, dependency, conflict, metric, and audit types.
- `src/components` contains reusable dashboard panels, graphs, registry tables, and monitors.
- No backend, external API, persistence layer, or internal model access simulation is used.

## Screen map

1. Protocol Inventory
2. Protocol Registry
3. Protocol Classification Matrix
4. Dependency Graph
5. Conflict Monitor
6. Risk Monitor
7. Governance Status
8. BP1 Status
9. Ecosystem Health Summary
10. Audit History

## Development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## Scope note

This dashboard represents observable APSRF components and documented protocol relationships. It does not simulate access to internal model architecture, hidden systems, or backend services.
